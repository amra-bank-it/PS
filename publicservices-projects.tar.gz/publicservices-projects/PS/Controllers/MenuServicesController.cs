﻿using Microsoft.AspNetCore.Mvc;
using Public_Services.Models;

namespace PS.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class MenuServicesController : ControllerBase
    {
        [HttpGet]
        public string GetMenu(string groupName)
        {
            string outMenu = "";
            try
            {
                using (var DD = new ServicesBD_1Context())
                {
                    var result = DD.PublicServices.Where(x => x.Gruppa == groupName).ToList();

                    foreach (var dd in result)
                        outMenu = outMenu + dd.AccountRecipientId + "=" + dd.NameButton + "|";
                    outMenu = outMenu.Substring(0, outMenu.Length - 1);
                }
            }
            catch (Exception err)
            {
                new Exception(err.ToString());
            }
            return outMenu;
        }
    }
}
