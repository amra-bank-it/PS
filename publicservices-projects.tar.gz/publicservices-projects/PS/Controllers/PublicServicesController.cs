﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Public_Services.Models;

namespace Public_Services.Controllers
{

    public class PublicServicesController : Controller
    {
        private readonly ServicesBD_1Context _context;

        public PublicServicesController(ServicesBD_1Context context)
        {
            _context = context;
        }

        // GET: PublicServices
        public async Task<IActionResult> DB()
        {
              return _context.PublicServices != null ? 
                          View(await _context.PublicServices.ToListAsync()) :
                          Problem("Entity set 'ServicesBD_1Context.PublicServices'  is null.");
        }


        // GET: PublicServices/Details/5
        public async Task<IActionResult> Details(Guid? id)
        {
            if (id == null || _context.PublicServices == null)
            {
                return NotFound();
            }

            var publicService = await _context.PublicServices
                .FirstOrDefaultAsync(m => m.AccountRecipientId == id);
            if (publicService == null)
            {
                return NotFound();
            }

            return View(publicService);
        }

        // GET: PublicServices/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PublicServices/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("RowId,KBK,INN,KPP,OKATO,Purpose,Recipient,Gruppa,NameButton,IsEnabled,Stamp,Amount,AccountRecipientId")] PublicService publicService)
        {
            if (ModelState.IsValid)
            {
                publicService.AccountRecipientId = Guid.NewGuid();
                _context.Add(publicService);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(DB));
            }
            return View(publicService);
        }

        // GET: PublicServices/Edit/5
        public async Task<IActionResult> Edit(Guid? id)
        {
            if (id == null || _context.PublicServices == null)
            {
                return NotFound();
            }

            var publicService = await _context.PublicServices.FindAsync(id);
            if (publicService == null)
            {
                return NotFound();
            }
            return View(publicService);
        }

        // POST: PublicServices/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Guid id, [Bind()] PublicService publicService)
        {
            if (id != publicService.AccountRecipientId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(publicService);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PublicServiceExists(publicService.AccountRecipientId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(DB));
            }
            return View(publicService);
        }

        // GET: PublicServices/Delete/5
        public async Task<IActionResult> Delete(Guid? id)
        {
            if (id == null || _context.PublicServices == null)
            {
                return NotFound();
            }

            var publicService = await _context.PublicServices
                .FirstOrDefaultAsync(m => m.AccountRecipientId == id);
            if (publicService == null)
            {
                return NotFound();
            }

            return View(publicService);
        }

        // POST: PublicServices/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(Guid id)
        {
            if (_context.PublicServices == null)
            {
                return Problem("Entity set 'ServicesBD_1Context.PublicServices'  is null.");
            }
            var publicService = await _context.PublicServices.FindAsync(id);
            if (publicService != null)
            {
                _context.PublicServices.Remove(publicService);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(DB));
        }

        private bool PublicServiceExists(Guid id)
        {
          return (_context.PublicServices?.Any(e => e.AccountRecipientId == id)).GetValueOrDefault();
        }

        [HttpPost, ActionName("Find")]
        public async Task<IActionResult> Find(Guid id, PublicService GROUP, string filter)
        {
            var dd = _context.PublicServices.Where(predicate: x => x.Gruppa.Contains(filter)).ToList();

            IEnumerable<PublicService> OutPers = dd;
            if (GROUP == null)
            {
                return NotFound();
            }
            else if (GROUP != null)
            {
                return View("DB", OutPers);
            }
            var publicService = await _context.PublicServices.FindAsync(id);

            return View("DB", OutPers);

        }
    }
}
