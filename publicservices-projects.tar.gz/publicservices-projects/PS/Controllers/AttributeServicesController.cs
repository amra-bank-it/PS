﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Public_Services.Models;

namespace PS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AttributeServicesController : ControllerBase
    {
        [HttpGet]
        public PublicService GetAttributes(Guid ID)
        {
            string outMenu = "";
            try
            {
                using (var DD = new ServicesBD_1Context())
                {
                    var result = DD.PublicServices.Where(x => x.AccountRecipientId == ID).FirstOrDefault();
                    return result;
                }
            }
            catch (Exception err)
            {
                new Exception(err.ToString());
            }
            return new PublicService();
        }

    }
}
