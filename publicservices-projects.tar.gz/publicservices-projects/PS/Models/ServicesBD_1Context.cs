﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace Public_Services.Models
{
    public partial class ServicesBD_1Context : DbContext
    {
        public ServicesBD_1Context()
        {
        }

        public ServicesBD_1Context(DbContextOptions<ServicesBD_1Context> options)
            : base(options)
        {
        }

        public virtual DbSet<PublicService> PublicServices { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=10.55.31.92,14002;Database=ServicesBD_1;user id=sa;password=*New_123#;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<PublicService>(entity =>
            {
                entity.HasKey(e => e.AccountRecipientId);

                entity.ToTable("Public_Services");

                entity.Property(e => e.AccountRecipientId)
                    .HasColumnName("ACCOUNT_RECIPIENT_ID")
                    .HasDefaultValueSql("(newid())");

                entity.Property(e => e.Amount)
                    .HasColumnType("money")
                    .HasColumnName("AMOUNT");

                entity.Property(e => e.Gruppa)
                    .HasMaxLength(15)
                    .HasColumnName("GRUPPA");

                entity.Property(e => e.INN)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("INN");

                entity.Property(e => e.IsEnabled).HasColumnName("IS_ENABLED");

                entity.Property(e => e.KBK)
                    .HasMaxLength(30)
                    .IsUnicode(false)
                    .HasColumnName("KBK");

                entity.Property(e => e.KPP)
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("KPP");

                entity.Property(e => e.NameButton)
                    .HasMaxLength(100)
                    .HasColumnName("name_button");

                entity.Property(e => e.OKATO)
                    .HasMaxLength(10)
                    .IsUnicode(false)
                    .HasColumnName("OKATO");

                entity.Property(e => e.Purpose)
                    .HasMaxLength(500)
                    .HasColumnName("PURPOSE");

                entity.Property(e => e.Recipient)
                    .HasMaxLength(500)
                    .HasColumnName("RECIPIENT");

                entity.Property(e => e.RowId)
                    .ValueGeneratedOnAdd()
                    .HasColumnName("row_id")
                    .Metadata.SetAfterSaveBehavior(PropertySaveBehavior.Ignore);

                entity.Property(e => e.Stamp)
                    .HasColumnType("datetime")
                    .HasColumnName("STAMP");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
