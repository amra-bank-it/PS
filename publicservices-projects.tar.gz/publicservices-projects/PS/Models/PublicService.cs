﻿using System;
using System.Collections.Generic;

namespace Public_Services.Models
{
    public partial class PublicService
    {
        public long RowId { get; set; }
        public string? KBK { get; set; }
        public string? INN { get; set; }
        public string? KPP { get; set; }
        public string? OKATO { get; set; }
        public string? Purpose { get; set; }
        public string? Recipient { get; set; }
        public string? Gruppa { get; set; }
        public string? NameButton { get; set; }
        public bool? IsEnabled { get; set; }
        public DateTime? Stamp { get; set; }
        public decimal? Amount { get; set; }
        public Guid AccountRecipientId { get; set; }
    }
}
